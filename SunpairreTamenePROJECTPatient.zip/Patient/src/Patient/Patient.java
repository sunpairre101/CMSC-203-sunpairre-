package Patient;

/*
 * Class: CMSC203
 * Instructor: Prof. Ahmed Tarek
 * Description: Represents an individual patient's information in the health system.
 * Due: 10/02/2024
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. I have not given my code to any student.
 * Print your Name here: Sunpairre Tamene
 */

public class Patient {
    private String first;
    private String middle;
    private String surname;
    private String address;
    private String municipality;
    private String province;
    private String zip;
    private String phone;
    private String emergencyContact;
    private String emergencyPhone;

    public Patient() {
    }

    public Patient(String first, String middle, String surname) {
        this.first = first;
        this.middle = middle;
        this.surname = surname;
    }

    public Patient(String first, String middle, String surname, String address, String municipality, String province, String zip, String phone, String emergencyContact, String emergencyPhone) {
        this.first = first;
        this.middle = middle;
        this.surname = surname;
        this.address = address;
        this.municipality = municipality;
        this.province = province;
        this.zip = zip;
        this.phone = phone;
        this.emergencyContact = emergencyContact;
        this.emergencyPhone = emergencyPhone;
    }

    public String getFirst() {
        return first;
    }

    public String getMiddle() {
        return middle;
    }

    public String getSurname() {
        return surname;
    }

    public String getAddress() {
        return address;
    }

    public String getMunicipality() {
        return municipality;
    }

    public String getProvince() {
        return province;
    }

    public String getZip() {
        return zip;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public String getEmergencyPhone() {
        return emergencyPhone;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public void setMiddle(String middle) {
        this.middle = middle;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public void setEmergencyPhone(String emergencyPhone) {
        this.emergencyPhone = emergencyPhone;
    }

    public String compileFullName() {
        return first + " " + middle + " " + surname;
    }

    public String formatAddress() {
        return address + ", " + municipality + ", " + province + " " + zip;
    }

    public String formatEmergencyContact() {
        return emergencyContact + " - " + emergencyPhone;
    }

    @Override
    public String toString() {
        return "Patient Profile:\n" +
               "\tFull Name: " + compileFullName() + "\n" +
               "\tAddress: " + formatAddress() + "\n" +
               "\tPhone: " + phone + "\n" +
               "\tEmergency Contact: " + formatEmergencyContact();
    }
}
