package Patient;

/*
 * Class: CMSC203
 * Instructor: Prof. Ahmed Tarek
 * Description: Represents a medical treatment undergone by a patient.
 * Due: 10/02/2024
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. I have not given my code to any student.
 * Print your Name here: Sunpairre Tamene
 */

public class Procedure {
    private String treatmentName;
    private String treatmentDate;
    private String attendingDoctor;
    private double cost;

    public Procedure() {
    }

    public Procedure(String treatmentName, String treatmentDate) {
        this.treatmentName = treatmentName;
        this.treatmentDate = treatmentDate;
    }

    public Procedure(String treatmentName, String treatmentDate, String attendingDoctor, double cost) {
        this.treatmentName = treatmentName;
        this.treatmentDate = treatmentDate;
        this.attendingDoctor = attendingDoctor;
        this.cost = cost;
    }

    public String getTreatmentName() {
        return treatmentName;
    }

    public String getTreatmentDate() {
        return treatmentDate;
    }

    public String getAttendingDoctor() {
        return attendingDoctor;
    }

    public double getCost() {
        return cost;
    }

    // Setters
    public void setTreatmentName(String treatmentName) {
        this.treatmentName = treatmentName;
    }

    public void setTreatmentDate(String treatmentDate) {
        this.treatmentDate = treatmentDate;
    }

    public void setAttendingDoctor(String attendingDoctor) {
        this.attendingDoctor = attendingDoctor;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    @Override
    public String toString() {
        return "Treatment Record:\n" + 
               "\tProcedure: " + treatmentName + "\n" +
               "\tDate: " + treatmentDate + "\n" +
               "\tDoctor: " + attendingDoctor + "\n" +
               "\tCharge: $" + String.format("%.2f", cost);
    }
}
