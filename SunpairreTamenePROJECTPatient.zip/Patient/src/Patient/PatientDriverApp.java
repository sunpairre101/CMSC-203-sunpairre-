package Patient;

import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor: Prof. Ahmed Tarek
 * Description: Main driver application to manage patient and procedure records.
 * Due: 10/2/2024
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. I have not given my code to any student.
 * Print your Name here: Sunpairre Tamene
 */

public class PatientDriverApp {
    
    public static void showPatientProfile(Patient patientInfo) {
        System.out.println(patientInfo.toString());
    }

    public static void showProcedureDetails(Procedure treatment) {
        System.out.println(treatment.toString());
    }

    public static void calculateTotalCost(Procedure treatment1, Procedure treatment2, Procedure treatment3) {
        double total = treatment1.getCost() + treatment2.getCost() + treatment3.getCost();
        System.out.println("Total Expense: $" + String.format("%.2f", total));
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        Patient patientInfo = new Patient("Nati", "Esayas", "Alemu", "799 Sligo Avenue", "Silver Spring", "MD", "20910", "987-321-2290", "Henok Abebe", "255-624-3210");
        
        Procedure procedure1 = new Procedure("EMRI", "10/02/2024", "Dr. Werku Ababa", 1700.00);
        Procedure procedure2 = new Procedure("X-Ray", "09/02/2024", "Dr. Emma Davis", 900.00);
        Procedure procedure3 = new Procedure("Urine Test", "08/02/2024", "Dr. Mike Teshome", 1600.00);
        
        showPatientProfile(patientInfo);
        showProcedureDetails(procedure1);
        showProcedureDetails(procedure2);
        showProcedureDetails(procedure3);
        
        calculateTotalCost(procedure1, procedure2, procedure3);
        
        System.out.println("Developed by: Sunpairre Tamene <10/02/24>");
        
        sc.close();
    }
}
